const STATE_PATH = process.env.BLOB_STATE_PATH || 'fut-manager/state.json';

function sendJson(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.end(JSON.stringify(body));
}

module.exports = async function handler(req, res) {
  try {
    const { list } = await import('@vercel/blob');
    const result = await list({ prefix: STATE_PATH.split('/').slice(0, -1).join('/') || undefined, limit: 1 });

    return sendJson(res, 200, {
      ok: true,
      storage: 'vercel-blob',
      hasToken: Boolean(process.env.BLOB_READ_WRITE_TOKEN),
      access: process.env.BLOB_ACCESS || 'private',
      statePath: STATE_PATH,
      blobsFound: result.blobs?.length || 0
    });
  } catch (error) {
    console.error(error);
    return sendJson(res, 500, {
      ok: false,
      storage: 'vercel-blob',
      hasToken: Boolean(process.env.BLOB_READ_WRITE_TOKEN),
      error: error.message || 'Erro interno.'
    });
  }
};
