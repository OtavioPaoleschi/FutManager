const MAX_BODY_BYTES = Number(process.env.MAX_STATE_BYTES || 5 * 1024 * 1024);
const STATE_PATH = process.env.BLOB_STATE_PATH || 'fut-manager/state.json';
const BLOB_ACCESS = process.env.BLOB_ACCESS || 'private'; // use 'public' only if your Blob store was created as Public

function sendJson(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.end(JSON.stringify(body));
}

async function readJsonBody(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  if (typeof req.body === 'string') return JSON.parse(req.body || '{}');

  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new Error('Payload maior que o limite configurado.');
    chunks.push(chunk);
  }

  const raw = Buffer.concat(chunks).toString('utf8');
  return raw ? JSON.parse(raw) : {};
}

async function streamToString(stream) {
  if (!stream) return '';

  // Vercel Blob returns a Web ReadableStream. This is the simplest way on Node 18+.
  if (typeof Response !== 'undefined') {
    return new Response(stream).text();
  }

  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(Buffer.from(chunk));
  }
  return Buffer.concat(chunks).toString('utf8');
}

function isNotFoundError(error) {
  const text = `${error?.name || ''} ${error?.message || ''}`.toLowerCase();
  return text.includes('notfound') || text.includes('not found') || text.includes('404');
}

module.exports = async function handler(req, res) {
  try {
    if (!['GET', 'PUT', 'POST'].includes(req.method)) {
      return sendJson(res, 405, { ok: false, error: 'Método não permitido.' });
    }

    if (!['private', 'public'].includes(BLOB_ACCESS)) {
      return sendJson(res, 500, { ok: false, error: 'BLOB_ACCESS precisa ser private ou public.' });
    }

    const { get, put } = await import('@vercel/blob');

    if (req.method === 'GET') {
      try {
        const result = await get(STATE_PATH, { access: BLOB_ACCESS });

        if (!result || result.statusCode !== 200 || !result.stream) {
          return sendJson(res, 200, {
            ok: true,
            storage: 'vercel-blob',
            data: null,
            updatedAt: null,
            path: STATE_PATH
          });
        }

        const raw = await streamToString(result.stream);
        const data = raw ? JSON.parse(raw) : null;

        return sendJson(res, 200, {
          ok: true,
          storage: 'vercel-blob',
          data,
          updatedAt: result.blob?.uploadedAt || null,
          etag: result.blob?.etag || null,
          path: STATE_PATH
        });
      } catch (error) {
        if (isNotFoundError(error)) {
          return sendJson(res, 200, {
            ok: true,
            storage: 'vercel-blob',
            data: null,
            updatedAt: null,
            path: STATE_PATH
          });
        }
        throw error;
      }
    }

    const body = await readJsonBody(req);
    const data = body && Object.prototype.hasOwnProperty.call(body, 'data') ? body.data : body;

    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return sendJson(res, 400, { ok: false, error: 'Envie um objeto JSON válido em { data: ... }.' });
    }

    const serialized = JSON.stringify(data);
    const bytes = Buffer.byteLength(serialized, 'utf8');

    if (bytes > MAX_BODY_BYTES) {
      return sendJson(res, 413, { ok: false, error: 'Dados maiores que o limite configurado.' });
    }

    const blob = await put(STATE_PATH, serialized, {
      access: BLOB_ACCESS,
      allowOverwrite: true,
      contentType: 'application/json; charset=utf-8',
      cacheControlMaxAge: 60
    });

    return sendJson(res, 200, {
      ok: true,
      storage: 'vercel-blob',
      bytes,
      path: blob.pathname,
      url: BLOB_ACCESS === 'public' ? blob.url : undefined,
      etag: blob.etag || null
    });
  } catch (error) {
    console.error(error);
    return sendJson(res, 500, { ok: false, error: error.message || 'Erro interno.' });
  }
};
