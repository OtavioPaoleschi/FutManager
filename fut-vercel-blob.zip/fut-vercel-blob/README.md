# Sistema do Fut — Vercel Blob

Esta versão usa **Vercel Blob** como armazenamento central. Em vez de MySQL, o app salva um JSON único em `fut-manager/state.json` dentro do Blob.

## Por que Blob e não Edge Config?

- **Blob**: bom para poucos dados, backup em JSON e um app simples de brincadeira.
- **Edge Config**: ótimo para ler configurações muito rápido, mas não é ideal para gravar jogo, gol e avaliação toda hora.

## Estrutura

```txt
index.html       SPA do Sistema do Fut
api/state.js     lê e salva o estado no Vercel Blob
api/health.js    testa se o Blob está conectado
package.json     dependências do deploy
```

## Como criar no Vercel

1. Faça upload/deploy deste projeto no Vercel.
2. No projeto, abra **Storage**.
3. Clique em **Blob > Create**.
4. Conecte o Blob ao projeto.
5. O Vercel deve criar automaticamente a variável de ambiente:

```txt
BLOB_READ_WRITE_TOKEN
```

6. Faça redeploy do projeto.
7. Teste:

```txt
https://SEU-PROJETO.vercel.app/api/health
```

Se estiver certo, deve retornar algo parecido com:

```json
{
  "ok": true,
  "blob": true,
  "access": "public",
  "statePath": "fut-manager/state.json"
}
```

## Dados públicos ou privados

Por padrão, o pacote usa:

```txt
FUT_BLOB_ACCESS=public
```

Como os dados são de brincadeira, isso simplifica. Se você criar um Blob privado, configure no Vercel:

```txt
FUT_BLOB_ACCESS=private
```

## Aviso importante

Essa versão salva o estado inteiro do app como um JSON. Para poucos jogadores e poucos jogos, é perfeito e simples.

Se duas pessoas salvarem ao mesmo tempo, o último salvamento pode sobrescrever o anterior. Para uso sério multiusuário, o ideal é trocar para banco relacional, por exemplo Postgres/Neon pelo Marketplace da Vercel ou MySQL externo.

## Migração de dados

O app ainda mantém cache local e exportação CSV. Depois do primeiro deploy, abra o app no celular que já tinha os dados locais e faça alguma alteração/salvamento para sincronizar o estado com o Blob.
