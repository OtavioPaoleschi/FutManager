function sendJson(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

module.exports = async function handler(req, res) {
  try {
    if (!process.env.BLOB_READ_WRITE_TOKEN) {
      return sendJson(res, 500, {
        ok: false,
        blob: false,
        error: 'BLOB_READ_WRITE_TOKEN não configurado.'
      });
    }

    const { list } = await import('@vercel/blob');
    await list({ limit: 1 });
    return sendJson(res, 200, {
      ok: true,
      blob: true,
      access: process.env.FUT_BLOB_ACCESS || 'public',
      statePath: process.env.FUT_STATE_PATH || 'fut-manager/state.json'
    });
  } catch (error) {
    console.error(error);
    return sendJson(res, 500, {
      ok: false,
      blob: false,
      error: error.message || 'Erro interno.'
    });
  }
};
