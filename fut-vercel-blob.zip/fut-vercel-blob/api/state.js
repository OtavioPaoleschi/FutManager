const MAX_BODY_BYTES = Number(process.env.MAX_STATE_BYTES || 5 * 1024 * 1024);
const STATE_PATH = process.env.FUT_STATE_PATH || 'fut-manager/state.json';
const BLOB_ACCESS = process.env.FUT_BLOB_ACCESS || 'public'; // use 'public' para dados de brincadeira; pode trocar para 'private'

function sendJson(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.end(JSON.stringify(body));
}

async function readJsonBody(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  if (typeof req.body === 'string') return JSON.parse(req.body || '{}');

  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new Error('Payload maior que o limite configurado.');
    chunks.push(chunk);
  }

  const raw = Buffer.concat(chunks).toString('utf8');
  return raw ? JSON.parse(raw) : {};
}

async function streamToString(stream) {
  if (!stream) return '';

  // Web ReadableStream
  if (typeof stream.getReader === 'function') {
    const reader = stream.getReader();
    const decoder = new TextDecoder();
    let output = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      output += decoder.decode(value, { stream: true });
    }
    output += decoder.decode();
    return output;
  }

  // Node stream / async iterable
  const chunks = [];
  for await (const chunk of stream) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks).toString('utf8');
}

async function getBlobSdk() {
  return import('@vercel/blob');
}

async function readStateFromBlob() {
  const { get } = await getBlobSdk();
  const result = await get(STATE_PATH, {
    access: BLOB_ACCESS,
    headers: { 'cache-control': 'no-cache' }
  });

  if (!result || result.statusCode !== 200 || !result.stream) {
    return { data: null, updatedAt: null, etag: null, pathname: STATE_PATH };
  }

  const raw = await streamToString(result.stream);
  const json = raw ? JSON.parse(raw) : null;

  // O arquivo salva um envelope. Se algum dia alguém subir o estado cru, aceitamos também.
  const data = json && Object.prototype.hasOwnProperty.call(json, 'data') ? json.data : json;
  const updatedAt = json && json.updatedAt ? json.updatedAt : result.blob.uploadedAt;

  return {
    data,
    updatedAt,
    etag: result.blob.etag,
    pathname: result.blob.pathname,
    url: result.blob.url
  };
}

async function writeStateToBlob(data) {
  const { put } = await getBlobSdk();
  const envelope = {
    data,
    updatedAt: new Date().toISOString(),
    app: 'fut-manager'
  };

  const blob = await put(STATE_PATH, JSON.stringify(envelope, null, 2), {
    access: BLOB_ACCESS,
    allowOverwrite: true,
    addRandomSuffix: false,
    contentType: 'application/json; charset=utf-8',
    // Vercel Blob não aceita menos de 60s. A API /api/state também manda no-store.
    cacheControlMaxAge: 60
  });

  return {
    data,
    updatedAt: envelope.updatedAt,
    etag: blob.etag,
    pathname: blob.pathname,
    url: blob.url
  };
}

module.exports = async function handler(req, res) {
  try {
    if (!['GET', 'PUT', 'POST'].includes(req.method)) {
      return sendJson(res, 405, { ok: false, error: 'Método não permitido.' });
    }

    if (!process.env.BLOB_READ_WRITE_TOKEN) {
      return sendJson(res, 500, {
        ok: false,
        error: 'BLOB_READ_WRITE_TOKEN não configurado. Crie um Blob no Vercel Storage e conecte ao projeto.'
      });
    }

    if (req.method === 'GET') {
      const state = await readStateFromBlob();
      return sendJson(res, 200, { ok: true, ...state });
    }

    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object' || !Object.prototype.hasOwnProperty.call(body, 'data')) {
      return sendJson(res, 400, { ok: false, error: 'Envie JSON no formato { "data": ... }.' });
    }

    const saved = await writeStateToBlob(body.data);
    return sendJson(res, 200, { ok: true, ...saved });
  } catch (error) {
    console.error(error);
    const message = error && error.message ? error.message : 'Erro interno.';

    // Quando o state.json ainda não existe, o app deve abrir com banco vazio.
    if (/not found|BlobNotFound/i.test(message)) {
      return sendJson(res, 200, { ok: true, data: null, updatedAt: null, etag: null, pathname: STATE_PATH });
    }

    return sendJson(res, 500, { ok: false, error: message });
  }
};
